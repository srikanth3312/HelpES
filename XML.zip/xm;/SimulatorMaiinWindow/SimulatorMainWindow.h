#ifndef SIMULATORMAINWINDOW_H
#define SIMULATORMAINWINDOW_H

#include <QMainWindow>
#include <QTextEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QWidget>

#include "TCPServerSimulator.h"
#include "CommonServerConfig.h" // For SourceGroup enum


QT_BEGIN_NAMESPACE
namespace Ui { class SimulatorMainWindow; }
QT_END_NAMESPACE

class SimulatorMainWindow : public QMainWindow
{
    Q_OBJECT

public:
    SimulatorMainWindow(QWidget *parent = nullptr);
    ~SimulatorMainWindow();
private slots:
    void startAllServers();
    void stopAllServers();
    void logMessage(SourceGroup group, const QString& message);

private:
    Ui::SimulatorMainWindow *ui;
    QTextEdit* m_logDisplay;
    QPushButton* m_startButton;
    QPushButton* m_stopButton;

    // Instances of our server simulators
    TCPServerSimulator* m_spServer;
    TCPServerSimulator* m_dtServer;
    TCPServerSimulator* m_gtServer;

    // Define ports for servers (should match client's DCS.properties)
    const quint16 SP_PORT = 12345;
    const quint16 DT_PORT = 12346;
    const quint16 GT_PORT = 12347;

};
#endif // SIMULATORMAINWINDOW_H
