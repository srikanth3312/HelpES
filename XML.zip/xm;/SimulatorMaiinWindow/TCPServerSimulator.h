#ifndef TCPSERVERSIMULATOR_H
#define TCPSERVERSIMULATOR_H

#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>
#include <QThread>
#include <QMap>
#include <QByteArray>
#include <QXmlStreamReader>
#include <QDataStream>
#include "CommonServerConfig.h" // Include our common types

// Enum to specify the communication protocol for this server type
enum SimulatorServerType {
    XML_PROTOCOL,
    BINARY_PROTOCOL
};

class TCPServerSimulator : public QObject
{
    Q_OBJECT
public:
    explicit TCPServerSimulator(SourceGroup group,quint16 port,SimulatorServerType type, QObject *parent = nullptr);
   ~TCPServerSimulator();
    // Starts the server listener in its own thread
    void startServer();
    // Stops the server and cleans up
    void stopServer();

signals:
    void serverLogMessage(SourceGroup group, const QString& message);
    void clientConnected(SourceGroup group, const QString& clientAddress);
    void clientDisconnected(SourceGroup group, const QString& clientAddress);

private slots:
    void acceptConnection();
       void processClientData();
      // void clientDisconnected();
       // void socketError(QAbstractSocket::SocketError socketError);

private:
    QTcpServer* m_tcpServer;          // The server listening socket
    QThread* m_serverThread;          // Thread for the QTcpServer itself
    SourceGroup m_group;              // Which server group this is (SP, Dt, GT)
    quint16 m_port;                   // Port to listen on
    SimulatorServerType m_type;       // Protocol type (XML or BINARY)

    // We'll map client sockets to their own handler threads for processing
    QMap<QTcpSocket*, QThread*> m_clientSocketHandlers;

    // --- Protocol specific parsing methods ---
    void parseXmlHeartbeat(QTcpSocket* socket, const QByteArray& data);
    void parseBinaryHeartbeat(QTcpSocket* socket, const QByteArray& data);

    // Helper to get the SourceGroup value from the socket's parent thread (if using parent association)
    // Or more reliably, track which simulator instance is handling it.
    SourceGroup getGroupFromSocket(QTcpSocket* socket); // We'll need a way to map socket back to group.

};

#endif // TCPSERVERSIMULATOR_H
