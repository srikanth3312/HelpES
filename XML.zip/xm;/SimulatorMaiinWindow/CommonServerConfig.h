#ifndef COMMONSERVERCONFIG_H
#define COMMONSERVERCONFIG_H

#include <QObject>
#include <QMap>
#include <QString>
#include <QDateTime>

// Source groups enum
// Ensure this matches the one in your client's CommonProperties.h
enum SourceGroup {
    SP = 0, // Assign integer values for easier handling with QDataStream
    Dt = 1,
    GT = 2
};
Q_DECLARE_METATYPE(SourceGroup) // Needed if passing SourceGroup in signals/slots

// Heartbeat message structure
// Ensure this matches the one in your client's CommonProperties.h
typedef struct {
    int nSource;
    QString strSource;
    int nSourceGroup;   // Store enum value as int
    int nRecevtTimestamp;
} HeartbeatMessage;
Q_DECLARE_METATYPE(HeartbeatMessage) // Needed if passing the whole struct in signals/slots

// Server configuration struct
struct ServerConfig {
    QString ip;
    quint16 port;
};

#endif // COMMONSERVERCONFIG_H
