#include "SimulatorMainWindow.h"
#include "ui_SimulatorMainWindow.h"

SimulatorMainWindow::SimulatorMainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::SimulatorMainWindow)
{
    ui->setupUi(this);
    // Central widget and layout
    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);

    // Log display
    m_logDisplay = new QTextEdit(this);
    m_logDisplay->setReadOnly(true);
    m_logDisplay->setPlaceholderText("Server logs will appear here...");
    mainLayout->addWidget(m_logDisplay);

    // Buttons layout
    QHBoxLayout *buttonLayout = new QHBoxLayout();
    m_startButton = new QPushButton("Start All Servers", this);
    m_stopButton = new QPushButton("Stop All Servers", this);
    m_stopButton->setEnabled(false); // Initially disabled

    buttonLayout->addWidget(m_startButton);
    buttonLayout->addWidget(m_stopButton);
    mainLayout->addLayout(buttonLayout);

    setCentralWidget(centralWidget);

    // Create server instances
    // SP server expects XML
    m_spServer = new TCPServerSimulator(SP, SP_PORT, XML_PROTOCOL, this);
    // Dt server expects Binary
    m_dtServer = new TCPServerSimulator(Dt, DT_PORT, BINARY_PROTOCOL, this);
    // Gt server expects Binary
    m_gtServer = new TCPServerSimulator(GT, GT_PORT, BINARY_PROTOCOL, this);

    // Connect signal for logging from servers to this window's log display
    connect(m_spServer, &TCPServerSimulator::serverLogMessage, this, &SimulatorMainWindow::logMessage);
    connect(m_dtServer, &TCPServerSimulator::serverLogMessage, this, &SimulatorMainWindow::logMessage);
    connect(m_gtServer, &TCPServerSimulator::serverLogMessage, this, &SimulatorMainWindow::logMessage);

    // Connect button signals to slots
    connect(m_startButton, &QPushButton::clicked, this, &SimulatorMainWindow::startAllServers);
    connect(m_stopButton, &QPushButton::clicked, this, &SimulatorMainWindow::stopAllServers);

    // Initialize window title
    setWindowTitle("TCP Server Simulators");

}

SimulatorMainWindow::~SimulatorMainWindow()
{
    stopAllServers();
    delete ui;
}
void SimulatorMainWindow::startAllServers()
{
    logMessage(SP, "Attempting to start all servers...");
    m_spServer->startServer();
    m_dtServer->startServer();
    m_gtServer->startServer();
    m_startButton->setEnabled(false);
    m_stopButton->setEnabled(true);
}

void SimulatorMainWindow::stopAllServers()
{
    logMessage(SP, "Attempting to stop all servers...");
    m_spServer->stopServer();
    m_dtServer->stopServer();
    m_gtServer->stopServer();
    m_startButton->setEnabled(true);
    m_stopButton->setEnabled(false);
}

void SimulatorMainWindow::logMessage(SourceGroup group, const QString& message)
{
    QString groupStr;
    switch(group) {
        case SP: groupStr = "SP"; break;
        case Dt: groupStr = "Dt"; break;
        case GT: groupStr = "GT"; break;
        default: groupStr = "Unknown"; break;
    }
    QString timestamp = QDateTime::currentDateTime().toString("HH:mm:ss.zzz");
    m_logDisplay->append(QString("[%1][%2]: %3").arg(timestamp).arg(groupStr).arg(message));
}

