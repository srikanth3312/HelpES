/********************************************************************************
** Form generated from reading UI file 'SimulatorMainWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SIMULATORMAINWINDOW_H
#define UI_SIMULATORMAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SimulatorMainWindow
{
public:
    QWidget *centralwidget;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *SimulatorMainWindow)
    {
        if (SimulatorMainWindow->objectName().isEmpty())
            SimulatorMainWindow->setObjectName(QString::fromUtf8("SimulatorMainWindow"));
        SimulatorMainWindow->resize(800, 600);
        centralwidget = new QWidget(SimulatorMainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        SimulatorMainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(SimulatorMainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        SimulatorMainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(SimulatorMainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        SimulatorMainWindow->setStatusBar(statusbar);

        retranslateUi(SimulatorMainWindow);

        QMetaObject::connectSlotsByName(SimulatorMainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *SimulatorMainWindow)
    {
        SimulatorMainWindow->setWindowTitle(QCoreApplication::translate("SimulatorMainWindow", "SimulatorMainWindow", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SimulatorMainWindow: public Ui_SimulatorMainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SIMULATORMAINWINDOW_H
