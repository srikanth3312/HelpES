#include "TCPServerSimulator.h"
#include <QHostAddress>
#include <QDebug>
#include <QDateTime>
#include <QXmlStreamReader>
#include <QXmlStreamWriter>
#include <QDataStream>


TCPServerSimulator::TCPServerSimulator(SourceGroup group, quint16 port, SimulatorServerType type, QObject *parent)
    : QObject(parent),
          m_group(group),
          m_port(port),
          m_type(type)

{
    m_tcpServer = new QTcpServer(this); // Parent is this object, so it's cleaned up if this object is deleted
    m_serverThread = nullptr; // Will be created when startServer() is called

    // Default to Binary Protocol if group is not SP, unless explicitly set to XML
    if (m_group != SP && m_type == XML_PROTOCOL) {
        qWarning() << "Warning: XML_PROTOCOL is only intended for SP. Group:" << m_group;
        // You might want to enforce this or handle it differently.
    }
}
TCPServerSimulator::~TCPServerSimulator()
{
    stopServer(); // Ensure cleanup
    if (m_tcpServer) {
        m_tcpServer->deleteLater(); // Schedule for deletion
        m_tcpServer = nullptr;
    }
    // The thread and handlers are managed more carefully below.
}

// Starts the server listener in its own thread
void TCPServerSimulator::startServer()
{
    if (m_serverThread) {
        emit serverLogMessage(m_group, "Server already started.");
        return;
    }

    m_serverThread = new QThread();
    this->moveToThread(m_serverThread); // Move the simulator logic to the new thread

    // Create the QTcpServer *after* moving to the thread.
    // This ensures the QTcpServer belongs to the correct thread.
    m_tcpServer = new QTcpServer(this);

    // Connect the QTcpServer's signals to slots *within this object*, which is now in m_serverThread.
    connect(m_tcpServer, &QTcpServer::newConnection, this, &TCPServerSimulator::acceptConnection);

    // Start the thread
    m_serverThread->start();
    emit serverLogMessage(m_group, "Server thread started.");

    // Now, start listening on the port. This must be done *after* moving to the thread.
    QHostAddress address = QHostAddress::AnyIPv4; // Listen on any interface
    if (!m_tcpServer->listen(address, m_port)) {
        emit serverLogMessage(m_group, QString("Server failed to start on port %1: %2")
                              .arg(m_port).arg(m_tcpServer->errorString()));
        stopServer(); // Clean up if listen fails
    } else {
        emit serverLogMessage(m_group, QString("Server started, listening on port %1 (Type: %2)")
                              .arg(m_port)
                              .arg(m_type == XML_PROTOCOL ? "XML" : "BINARY"));
    }
}

// Stops the server and cleans up
void TCPServerSimulator::stopServer()
{
    // Disconnect all existing client connections
    for (auto clientSocket : m_clientSocketHandlers.keys()) {
        if (clientSocket) {
            clientSocket->disconnectFromHost();
            clientSocket->close();
            // Schedule the socket for deletion and its thread for quitting
            if (m_clientSocketHandlers.value(clientSocket)) {
                m_clientSocketHandlers.value(clientSocket)->quit();
            }
            clientSocket->deleteLater();
        }
    }
    m_clientSocketHandlers.clear(); // Clear the map

    if (m_tcpServer && m_tcpServer->isListening()) {
        m_tcpServer->close();
        emit serverLogMessage(m_group, "Server stopped listening.");
    }

    if (m_serverThread && m_serverThread->isRunning()) {
        m_serverThread->quit(); // Signal the thread to exit
        m_serverThread->wait(1000); // Wait briefly for cleanup
        if (m_serverThread->isRunning()) {
            qWarning() << "Server thread did not quit gracefully for group" << m_group;
        }
        m_serverThread->deleteLater();
        m_serverThread = nullptr;
        emit serverLogMessage(m_group, "Server thread cleaned up.");
    }
}

// Slot called when QTcpServer detects a new incoming connection
void TCPServerSimulator::acceptConnection()
{
    // This slot runs in the m_serverThread context.
    while (m_tcpServer->hasPendingConnections()) {
        QTcpSocket* clientSocket = m_tcpServer->nextPendingConnection();
        if (!clientSocket) {
            emit serverLogMessage(m_group, "Error accepting client connection: null socket.");
            continue;
        }

        // We need to process each client's data in its own thread to prevent blocking
        // the main server listening thread.
        QThread* clientThread = new QThread(this); // Use 'this' as parent for lifetime management
        m_clientSocketHandlers.insert(clientSocket, clientThread);

        // Move the socket and connect signals/slots *within the new client thread*.
        // The slots (processClientData, clientDisconnected, socketError) will be called in clientThread.
        clientSocket->moveToThread(clientThread);

        // Connect signals from the socket to the appropriate slots in the socket's thread context.
        connect(clientSocket, &QTcpSocket::readyRead, this, &TCPServerSimulator::processClientData);
//        connect(clientSocket, &QTcpSocket::disconnected,
//                      this, &TCPServerSimulator::clientDisconnected);

//               connect(clientSocket, &QTcpSocket::errorOccurred,
//                      this, &TCPServerSimulator::socketError);

        // Also connect the thread's finished signal to delete the socket and the thread.
        connect(clientThread, &QThread::finished, clientSocket, &QObject::deleteLater);
        connect(clientThread, &QThread::finished, clientThread, &QObject::deleteLater);

        // Start the client's processing thread
        clientThread->start();

        QString clientAddress = clientSocket->peerAddress().toString() + ":" + QString::number(clientSocket->peerPort());
        emit serverLogMessage(m_group, QString("Client connected: %1").arg(clientAddress));
        emit clientConnected(m_group, clientAddress);
    }
}

// Slot to process data received from a client socket
void TCPServerSimulator::processClientData()
{
    // QTcpSocket::readyRead signal is emitted in the thread the socket belongs to.
    // Since we moved sockets to client threads, this slot is executed in one of those client threads.
    QTcpSocket* socket = qobject_cast<QTcpSocket*>(sender());
    if (!socket) return;

    QByteArray receivedData = socket->readAll(); // Read all available data

    QString clientAddress = socket->peerAddress().toString() + ":" + QString::number(socket->peerPort());

    if (m_type == XML_PROTOCOL) {
        parseXmlHeartbeat(socket, receivedData);
    } else { // BINARY_PROTOCOL
        parseBinaryHeartbeat(socket, receivedData);
    }
}

// Slot called when a client socket disconnects
//void TCPServerSimulator::clientDisconnected()
//{
//    QTcpSocket* socket = qobject_cast<QTcpSocket*>(sender());
//    if (!socket) return;

//    QString clientAddress = socket->peerAddress().toString() + ":" + QString::number(socket->peerPort());
//    emit serverLogMessage(m_group, QString("Client disconnected: %1").arg(clientAddress));
//    emit clientDisconnected(m_group, clientAddress);

//    // Clean up the thread associated with this socket.
//    QThread* clientThread = m_clientSocketHandlers.value(socket, nullptr);
//    if (clientThread) {
//        clientThread->quit(); // Signal the thread to exit
//        // The connection `connect(clientThread, &QThread::finished, socket, &QObject::deleteLater);`
//        // and `connect(clientThread, &QThread::finished, clientThread, &QObject::deleteLater);`
//        // will handle the actual deletion.
//    }
//    m_clientSocketHandlers.remove(socket); // Remove from our tracking map
//}

//// Slot to handle socket errors
//void TCPServerSimulator::socketError(QAbstractSocket::SocketError socketError)
//{
//    QTcpSocket* socket = qobject_cast<QTcpSocket*>(sender());
//    if (!socket) return;

//    emit serverLogMessage(m_group, QString("Socket error: %1").arg(socket->errorString()));
//    socket->disconnectFromHost();
//}

// --- Parsing Methods ---

void TCPServerSimulator::parseXmlHeartbeat(QTcpSocket* socket, const QByteArray& data)
{
    QXmlStreamReader xmlReader(data);
    HeartbeatMessage msg = {}; // Initialize with default values
    bool parsingOk = false;

    if (!xmlReader.readNextStartElement()) {
        emit serverLogMessage(m_group, "XML parse error: No start element.");
        return;
    }

    if (xmlReader.name() != "Heartbeat") {
        emit serverLogMessage(m_group, QString("XML parse error: Expected <Heartbeat>, got <%1>").arg(xmlReader.name().toString()));
        return;
    }

    while (xmlReader.readNextStartElement()) {
        if (xmlReader.name() == "SourceId") {
            msg.nSource = xmlReader.readElementText().toInt();
        } else if (xmlReader.name() == "SourceName") {
            msg.strSource = xmlReader.readElementText();
        } else if (xmlReader.name() == "SourceGroup") {
            msg.nSourceGroup = xmlReader.readElementText().toInt();
        } else if (xmlReader.name() == "Timestamp") {
            msg.nRecevtTimestamp = xmlReader.readElementText().toInt();
        } else {
            // Unknown element, skip it or log a warning
            xmlReader.skipCurrentElement();
        }
    }

    // Check if we successfully read key fields
    if (xmlReader.hasError()) {
        emit serverLogMessage(m_group, QString("XML parse error: %1 at line %2, column %3")
                              .arg(xmlReader.errorString())
                              .arg(xmlReader.lineNumber())
                              .arg(xmlReader.columnNumber()));
    } else {
        parsingOk = true;
        QString logMsg = QString("Received XML Heartbeat: SourceId=%1, SourceName=%2, SourceGroup=%3, Timestamp=%4")
                                .arg(msg.nSource)
                                .arg(msg.strSource)
                                .arg(msg.nSourceGroup)
                                .arg(msg.nRecevtTimestamp);
        emit serverLogMessage(m_group, logMsg);

        // Optional: You could send an XML acknowledgment back to the client here
        // For example, using QXmlStreamWriter
        // QByteArray ackBlock;
        // QXmlStreamWriter xmlWriter(&ackBlock);
        // ... write acknowledgment XML ...
        // socket->write(ackBlock);
    }
}

void TCPServerSimulator::parseBinaryHeartbeat(QTcpSocket* socket, const QByteArray& data)
{
    QDataStream in(data);
    in.setVersion(QDataStream::Qt_5_14); // Match client's version

    HeartbeatMessage msg = {}; // Initialize with default values

    // The client's binary heartbeat sends int, int.
    // Ensure the data size is sufficient.
    if (data.size() < (sizeof(int) + sizeof(int))) {
        emit serverLogMessage(m_group, "Binary parse error: Incomplete data received.");
        return;
    }

    in >> msg.nSource;
    in >> msg.nRecevtTimestamp;

    // If your client also sent strSource and nSourceGroup in binary, you'd need to adapt
    // this parsing to match the exact binary format (e.g., length prefixes for strings).
    // For this example, we assume only nSource and nRecevtTimestamp are sent in binary.
    // The client's original code had `out << msg.nSource; out << msg.nRecevtTimestamp;` for binary.
    // If `strSource` and `nSourceGroup` were meant to be sent in binary too, the client code needs to change.
    // For now, we'll set them to default/unknown values for logging.

    QString logMsg = QString("Received Binary Heartbeat: SourceId=%1, Timestamp=%2")
                           .arg(msg.nSource)
                           .arg(msg.nRecevtTimestamp);
    emit serverLogMessage(m_group, logMsg);

    // Optional: You could send an acknowledgment back to the client here
    // For example, sending the timestamp back or a simple success code.
    // QByteArray ackBlock;
    // QDataStream outAck(&ackBlock, QIODevice::WriteOnly);
    // outAck.setVersion(QDataStream::Qt_5_14);
    // outAck << (qint32)0; // Dummy success code
    // outAck << msg.nRecevtTimestamp; // Echo timestamp
    // socket->write(ackBlock);
}

// Helper function to determine the SourceGroup of a socket.
// This is important if multiple server simulators share the same QTcpServer parent or if we didn't use separate QTcpServers.
// In our current design, the TCPServerSimulator instance is already tied to a group, and sockets are handled by it.
// So, we can simply use m_group within the instance.
// However, if we had a single QTcpServer handling multiple types, we'd need a way to map sockets back to their intended type.
// For this setup, `m_group` is sufficient within the handler slots.
// The following function is more illustrative of a complex scenario or if you wanted to map sockets globally.
/*
SourceGroup TCPServerSimulator::getGroupFromSocket(QTcpSocket* socket)
{
    // This is a simplified example. In a more complex setup where one QTcpServer
    // might manage sockets of different types, you'd need a mapping.
    // Since each TCPServerSimulator manages its own sockets and is tied to a SourceGroup,
    // we can directly use m_group.
    return m_group;
}
*/
