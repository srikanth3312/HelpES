/********************************************************************************
** Form generated from reading UI file 'ConnectionStatusDisplay.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONNECTIONSTATUSDISPLAY_H
#define UI_CONNECTIONSTATUSDISPLAY_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ConnectionStatusDisplay
{
public:
    QLabel *labelSPStatus;
    QLabel *labelDTStatus;
    QLabel *labelGTStatus;

    void setupUi(QWidget *ConnectionStatusDisplay)
    {
        if (ConnectionStatusDisplay->objectName().isEmpty())
            ConnectionStatusDisplay->setObjectName(QString::fromUtf8("ConnectionStatusDisplay"));
        ConnectionStatusDisplay->resize(400, 300);
        labelSPStatus = new QLabel(ConnectionStatusDisplay);
        labelSPStatus->setObjectName(QString::fromUtf8("labelSPStatus"));
        labelSPStatus->setGeometry(QRect(30, 20, 81, 21));
        labelDTStatus = new QLabel(ConnectionStatusDisplay);
        labelDTStatus->setObjectName(QString::fromUtf8("labelDTStatus"));
        labelDTStatus->setGeometry(QRect(30, 60, 91, 31));
        labelGTStatus = new QLabel(ConnectionStatusDisplay);
        labelGTStatus->setObjectName(QString::fromUtf8("labelGTStatus"));
        labelGTStatus->setGeometry(QRect(40, 110, 91, 31));

        retranslateUi(ConnectionStatusDisplay);

        QMetaObject::connectSlotsByName(ConnectionStatusDisplay);
    } // setupUi

    void retranslateUi(QWidget *ConnectionStatusDisplay)
    {
        ConnectionStatusDisplay->setWindowTitle(QCoreApplication::translate("ConnectionStatusDisplay", "Form", nullptr));
        labelSPStatus->setText(QString());
        labelDTStatus->setText(QString());
        labelGTStatus->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class ConnectionStatusDisplay: public Ui_ConnectionStatusDisplay {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONNECTIONSTATUSDISPLAY_H
