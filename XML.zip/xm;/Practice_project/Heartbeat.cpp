#include "Heartbeat.h"
#include "ui_Heartbeat.h"
#include <QDateTime>

Heartbeat::Heartbeat(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Heartbeat)
{
    ui->setupUi(this);
    // Initialize table
     ui->tableWidget->setColumnCount(4);
     QStringList headers = {"Source ID", "Source Name", "Source Group", "Timestamp"};
     ui->tableWidget->setHorizontalHeaderLabels(headers);

     // Setup timers
     updateTimer = new QTimer(this);
     connect(updateTimer, &QTimer::timeout, this, &Heartbeat::updateTable);
     updateTimer->start(100); // Update every 100ms

     timeoutTimer = new QTimer(this);
     connect(timeoutTimer, &QTimer::timeout, this, &Heartbeat::checkConnectionTimeout);
     timeoutTimer->start(1000); // Check every second

     // Initialize last heartbeat times
     lastHeartbeatTime[SP] = 0;
     lastHeartbeatTime[DT] = 0;
     lastHeartbeatTime[GT] = 0;

}

Heartbeat::~Heartbeat()
{
    delete ui;
}
void Heartbeat::addHeartbeatData(const HeartbeatData& data)
{
    QMutexLocker locker(&queueMutex);
    heartbeatQueue.enqueue(data);

    // Update last heartbeat time
    lastHeartbeatTime[static_cast<SourceGroup>(data.nSourceGroup)] = QDateTime::currentMSecsSinceEpoch();
}

void Heartbeat::TriggerToUpdateConnStatus()
{
    updateTable();
}

void Heartbeat::updateTable()
{
    QMutexLocker locker(&queueMutex);

    while (!heartbeatQueue.isEmpty()) {
        HeartbeatData data = heartbeatQueue.dequeue();

        // Add row to table
        int row = ui->tableWidget->rowCount();
        ui->tableWidget->insertRow(row);

        ui->tableWidget->setItem(row, 0, new QTableWidgetItem(QString::number(data.nSource)));
        ui->tableWidget->setItem(row, 1, new QTableWidgetItem(data.strSource));

        QString groupName;
        switch (data.nSourceGroup) {
            case SP: groupName = "SP"; break;
            case DT: groupName = "DT"; break;
            case GT: groupName = "GT"; break;
        }
        ui->tableWidget->setItem(row, 2, new QTableWidgetItem(groupName));

        QDateTime timestamp;
        timestamp.setSecsSinceEpoch(data.nReceiveTimestamp);
        ui->tableWidget->setItem(row, 3, new QTableWidgetItem(timestamp.toString("yyyy-MM-dd hh:mm:ss")));

        // Keep only last 100 rows
        if (ui->tableWidget->rowCount() > 100) {
            ui->tableWidget->removeRow(0);
        }
    }
}

void Heartbeat::checkConnectionTimeout()
{
    qint64 currentTime = QDateTime::currentMSecsSinceEpoch();
    int timeout = CommonProperties::getInstance().getProperties().value("CONNECTION_TIMEOUT", "10000").toInt();

    for (auto it = lastHeartbeatTime.begin(); it != lastHeartbeatTime.end(); ++it) {
        bool connected = (currentTime - it.value()) < timeout;
        emit connectionStatusChanged(it.key(), connected);
    }
}
