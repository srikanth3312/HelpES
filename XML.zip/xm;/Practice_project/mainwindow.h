#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFile>
#include "structure.h"
#include "splitbin.h"
#include "Client.h"
#include "Heartbeat.h"
#include "ConnectionStatusDisplay.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
private slots:
    void onStartClicked();
      void onStopClicked();
      void onHeartbeatReceived(const HeartbeatData& data);
      void onConnectionStatusChanged(SourceGroup group, bool connected);
//    void onHeartbeatReceived(const ::HeartbeatData& hb);
//    void onConnectionStatusChanged(SourceGroup group, bool status);

private:
    Ui::MainWindow *ui;
    SplitBin *splitBin;
    Client* m_client;
    Heartbeat *heartbeatWidget;
        ConnectionStatusDisplay *statusDisplay;
    //void SetupConnections();
//    void setupUI();
//    void loadConfiguration();

};
#endif // MAINWINDOW_H
