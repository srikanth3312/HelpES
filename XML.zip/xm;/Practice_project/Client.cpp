#include "Client.h"
#include <QDataStream>
#include <QDomDocument>
#include <QDateTime>
#include <QDebug>

ClientWorker::ClientWorker(SourceGroup group, QObject *parent)
    : QObject(parent), sourceGroup(group)
    , isRunning(false) {
    socket = new QTcpSocket(this);
       heartbeatTimer = new QTimer(this);
       reconnectTimer = new QTimer(this);

       connect(socket, &QTcpSocket::connected, this, &ClientWorker::onConnected);
       connect(socket, &QTcpSocket::disconnected, this, &ClientWorker::onDisconnected);
       connect(socket, &QTcpSocket::readyRead, this, &ClientWorker::onReadyRead);
       connect(socket, QOverload<QAbstractSocket::SocketError>::of(&QAbstractSocket::error),
               this, &ClientWorker::onError);

       connect(heartbeatTimer, &QTimer::timeout, this, &ClientWorker::sendHeartbeat);
       connect(reconnectTimer, &QTimer::timeout, this, &ClientWorker::connectToServer);

       int heartbeatInterval = CommonProperties::getInstance().getProperties().value("HEARTBEAT_INTERVAL", "5000").toInt();
       heartbeatTimer->setInterval(heartbeatInterval);
       reconnectTimer->setInterval(5000); // Reconnect every 5 seconds if disconnected
}

ClientWorker::~ClientWorker() {
    stop();
}

void ClientWorker::start()
{
    isRunning = true;
    connectToServer();
}

void ClientWorker::stop()
{
    isRunning = false;
    heartbeatTimer->stop();
    reconnectTimer->stop();
    if (socket->state() == QTcpSocket::ConnectedState) {
        socket->disconnectFromHost();
    }
}

void ClientWorker::connectToServer()
{
    if (!isRunning) return;

    QString ip = CommonProperties::getInstance().getServerIP(sourceGroup);
    int port = CommonProperties::getInstance().getServerPort(sourceGroup);

    qDebug() << "Connecting to" << ip << ":" << port << "for group" << sourceGroup;
    socket->connectToHost(ip, port);
}

void ClientWorker::onConnected()
{
    qDebug() << "Connected to server for group" << sourceGroup;
    emit connectionStatusChanged(sourceGroup, true);
    reconnectTimer->stop();
    heartbeatTimer->start();
    sendHeartbeat(); // Send initial heartbeat
}

void ClientWorker::onDisconnected()
{
    qDebug() << "Disconnected from server for group" << sourceGroup;
    emit connectionStatusChanged(sourceGroup, false);
    heartbeatTimer->stop();
    if (isRunning) {
        reconnectTimer->start();
    }
}

void ClientWorker::onReadyRead()
{
    QByteArray data = socket->readAll();
    HeartbeatData heartbeat = deserializeHeartbeat(data);
    emit heartbeatReceived(heartbeat);
}

void ClientWorker::onError(QAbstractSocket::SocketError socketError)
{
    Q_UNUSED(socketError)
    emit error(socket->errorString());
    emit connectionStatusChanged(sourceGroup, false);
    if (isRunning && !reconnectTimer->isActive()) {
        reconnectTimer->start();
    }
}

void ClientWorker::sendHeartbeat()
{
    HeartbeatData data;
    data.nSource = static_cast<int>(sourceGroup);
    data.strSource = QString("Client_%1").arg(sourceGroup);
    data.nSourceGroup = sourceGroup;
    data.nReceiveTimestamp = QDateTime::currentSecsSinceEpoch();

    QByteArray message;

    if (sourceGroup == SP) {
        // Send XML format for SP server
        QString xml = createXMLHeartbeat(data);
        message = xml.toUtf8();
    } else {
        // Send binary format for DT and GT servers
        message = serializeHeartbeat(data);
    }

    if (socket->state() == QTcpSocket::ConnectedState) {
        socket->write(message);
        socket->flush();
    }
}

QString ClientWorker::createXMLHeartbeat(const HeartbeatData& data)
{
    QDomDocument doc;
    QDomElement root = doc.createElement("Heartbeat");
    doc.appendChild(root);

    QDomElement sourceElem = doc.createElement("Source");
    sourceElem.appendChild(doc.createTextNode(QString::number(data.nSource)));
    root.appendChild(sourceElem);

    QDomElement sourceNameElem = doc.createElement("SourceName");
    sourceNameElem.appendChild(doc.createTextNode(data.strSource));
    root.appendChild(sourceNameElem);

    QDomElement groupElem = doc.createElement("SourceGroup");
    groupElem.appendChild(doc.createTextNode(QString::number(data.nSourceGroup)));
    root.appendChild(groupElem);

    QDomElement timestampElem = doc.createElement("Timestamp");
    timestampElem.appendChild(doc.createTextNode(QString::number(data.nReceiveTimestamp)));
    root.appendChild(timestampElem);

    return doc.toString();
}

QByteArray ClientWorker::serializeHeartbeat(const HeartbeatData& data)
{
    QByteArray buffer;
    QDataStream stream(&buffer, QIODevice::WriteOnly);
    stream.setVersion(QDataStream::Qt_5_14);

    stream << data.nSource;
    stream << data.strSource;
    stream << data.nSourceGroup;
    stream << data.nReceiveTimestamp;

    return buffer;
}

HeartbeatData ClientWorker::deserializeHeartbeat(const QByteArray& data)
{
    HeartbeatData heartbeat;
    QDataStream stream(data);
    stream.setVersion(QDataStream::Qt_5_14);

    stream >> heartbeat.nSource;
    stream >> heartbeat.strSource;
    stream >> heartbeat.nSourceGroup;
    stream >> heartbeat.nReceiveTimestamp;

    return heartbeat;
}

// Client class implementation
Client::Client(QObject *parent)
    : QObject(parent)
{
    // Create threads
    spThread = new QThread(this);
    dtThread = new QThread(this);
    gtThread = new QThread(this);

    // Create workers
    spWorker = new ClientWorker(SP);
    dtWorker = new ClientWorker(DT);
    gtWorker = new ClientWorker(GT);

    // Move workers to threads
    spWorker->moveToThread(spThread);
    dtWorker->moveToThread(dtThread);
    gtWorker->moveToThread(gtThread);

    // Connect signals
    connect(spThread, &QThread::started, spWorker, &ClientWorker::start);
    connect(dtThread, &QThread::started, dtWorker, &ClientWorker::start);
    connect(gtThread, &QThread::started, gtWorker, &ClientWorker::start);

    // Forward heartbeat signals
    connect(spWorker, &ClientWorker::heartbeatReceived, this, &Client::heartbeatReceived);
    connect(dtWorker, &ClientWorker::heartbeatReceived, this, &Client::heartbeatReceived);
    connect(gtWorker, &ClientWorker::heartbeatReceived, this, &Client::heartbeatReceived);

    // Forward connection status signals
    connect(spWorker, &ClientWorker::connectionStatusChanged, this, &Client::connectionStatusChanged);
    connect(dtWorker, &ClientWorker::connectionStatusChanged, this, &Client::connectionStatusChanged);
    connect(gtWorker, &ClientWorker::connectionStatusChanged, this, &Client::connectionStatusChanged);
}

Client::~Client()
{
    stopAllClients();
}

void Client::startAllClients()
{
    spThread->start();
    dtThread->start();
    gtThread->start();
}

void Client::stopAllClients()
{
    spWorker->stop();
    dtWorker->stop();
    gtWorker->stop();

    spThread->quit();
    dtThread->quit();
    gtThread->quit();

    spThread->wait();
    dtThread->wait();
    gtThread->wait();
}
