/********************************************************************************
** Form generated from reading UI file 'splitbin.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SPLITBIN_H
#define UI_SPLITBIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SplitBin
{
public:
    QLabel *filePathLabel1;
    QLabel *filePathLabel2;
    QLabel *filePathLabel3;
    QPushButton *browseButton1;
    QPushButton *browseButton2;
    QPushButton *browseButton3;
    QPushButton *splitButton;
    QProgressBar *progressBar1;
    QProgressBar *progressBar2;
    QProgressBar *progressBar3;
    QLabel *statusLabel;

    void setupUi(QWidget *SplitBin)
    {
        if (SplitBin->objectName().isEmpty())
            SplitBin->setObjectName(QString::fromUtf8("SplitBin"));
        SplitBin->resize(485, 477);
        filePathLabel1 = new QLabel(SplitBin);
        filePathLabel1->setObjectName(QString::fromUtf8("filePathLabel1"));
        filePathLabel1->setGeometry(QRect(20, 30, 151, 31));
        filePathLabel2 = new QLabel(SplitBin);
        filePathLabel2->setObjectName(QString::fromUtf8("filePathLabel2"));
        filePathLabel2->setGeometry(QRect(20, 90, 161, 16));
        filePathLabel3 = new QLabel(SplitBin);
        filePathLabel3->setObjectName(QString::fromUtf8("filePathLabel3"));
        filePathLabel3->setGeometry(QRect(20, 120, 151, 16));
        browseButton1 = new QPushButton(SplitBin);
        browseButton1->setObjectName(QString::fromUtf8("browseButton1"));
        browseButton1->setGeometry(QRect(250, 20, 93, 28));
        browseButton2 = new QPushButton(SplitBin);
        browseButton2->setObjectName(QString::fromUtf8("browseButton2"));
        browseButton2->setGeometry(QRect(250, 70, 93, 28));
        browseButton3 = new QPushButton(SplitBin);
        browseButton3->setObjectName(QString::fromUtf8("browseButton3"));
        browseButton3->setGeometry(QRect(260, 130, 93, 28));
        splitButton = new QPushButton(SplitBin);
        splitButton->setObjectName(QString::fromUtf8("splitButton"));
        splitButton->setGeometry(QRect(230, 210, 93, 28));
        progressBar1 = new QProgressBar(SplitBin);
        progressBar1->setObjectName(QString::fromUtf8("progressBar1"));
        progressBar1->setGeometry(QRect(40, 320, 251, 23));
        progressBar1->setValue(24);
        progressBar2 = new QProgressBar(SplitBin);
        progressBar2->setObjectName(QString::fromUtf8("progressBar2"));
        progressBar2->setGeometry(QRect(40, 360, 241, 23));
        progressBar2->setValue(24);
        progressBar3 = new QProgressBar(SplitBin);
        progressBar3->setObjectName(QString::fromUtf8("progressBar3"));
        progressBar3->setGeometry(QRect(40, 410, 231, 23));
        progressBar3->setValue(24);
        statusLabel = new QLabel(SplitBin);
        statusLabel->setObjectName(QString::fromUtf8("statusLabel"));
        statusLabel->setGeometry(QRect(330, 370, 101, 41));

        retranslateUi(SplitBin);

        QMetaObject::connectSlotsByName(SplitBin);
    } // setupUi

    void retranslateUi(QWidget *SplitBin)
    {
        SplitBin->setWindowTitle(QCoreApplication::translate("SplitBin", "Form", nullptr));
        filePathLabel1->setText(QString());
        filePathLabel2->setText(QString());
        filePathLabel3->setText(QString());
        browseButton1->setText(QCoreApplication::translate("SplitBin", "browse", nullptr));
        browseButton2->setText(QCoreApplication::translate("SplitBin", "browse", nullptr));
        browseButton3->setText(QCoreApplication::translate("SplitBin", "browse", nullptr));
        splitButton->setText(QCoreApplication::translate("SplitBin", "Split", nullptr));
        statusLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class SplitBin: public Ui_SplitBin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SPLITBIN_H
