/********************************************************************************
** Form generated from reading UI file 'Heartbeat.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HEARTBEAT_H
#define UI_HEARTBEAT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Heartbeat
{
public:
    QTableWidget *tableWidget;

    void setupUi(QWidget *Heartbeat)
    {
        if (Heartbeat->objectName().isEmpty())
            Heartbeat->setObjectName(QString::fromUtf8("Heartbeat"));
        Heartbeat->resize(400, 300);
        tableWidget = new QTableWidget(Heartbeat);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(20, 20, 256, 192));

        retranslateUi(Heartbeat);

        QMetaObject::connectSlotsByName(Heartbeat);
    } // setupUi

    void retranslateUi(QWidget *Heartbeat)
    {
        Heartbeat->setWindowTitle(QCoreApplication::translate("Heartbeat", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Heartbeat: public Ui_Heartbeat {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HEARTBEAT_H
