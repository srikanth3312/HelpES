#ifndef CONNECTIONSTATUSDISPLAY_H
#define CONNECTIONSTATUSDISPLAY_H

#include <QWidget>
#include <QMap>
#include <QLabel>
#include "CommonProperties.h"


namespace Ui {
class ConnectionStatusDisplay;
}

class ConnectionStatusDisplay : public QWidget
{
    Q_OBJECT

public:
    explicit ConnectionStatusDisplay(QWidget *parent = nullptr);
    ~ConnectionStatusDisplay();

public slots:
    void updateConnectionStatus(SourceGroup group, bool connected);

private:
    Ui::ConnectionStatusDisplay *ui;
    void setServerStatus(SourceGroup group, bool connected);

};

#endif // CONNECTIONSTATUSDISPLAY_H
