#ifndef STRUCTURE_H
#define STRUCTURE_H

#include <QString>

#define HEADER "srikanth"  // 8 bytes
#define DCS_ID_1 0x01      // 00000001
#define DCS_ID_2 0x02      // 00000010
#define DCS_ID_3 0x03      // 00000011
#define EOF_MARKER 0x0F    // 48 bits (0x0F repeated 6 times)

#pragma pack(push, 1)  // Ensure byte alignment
typedef struct {
    char header[8];           // "srikanth" in binary
    unsigned char dcs_id;     // 8 bits (1 byte)
    unsigned char bin_id;     // 1 byte
    unsigned int freq_min;    // 4 bytes
    unsigned int freq_max;    // 4 bytes
    unsigned int pulse_width_min;  // 4 bytes
    unsigned int pulse_width_max;  // 4 bytes
    unsigned int start_time;  // 4 bytes
    unsigned int end_time;    // 4 bytes
    unsigned int pdData_repeation_count;  // 4 bytes
    // pdData will be appended after the structure
    char EndofFrame[6];       // 48 bits (0x0F repeated 6 times)
} pdd;
#pragma pack(pop)

QByteArray createPddStructure(int dcs_id, const QString& pdFilePath);

#endif // STRUCTURE_H
