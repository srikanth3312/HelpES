#ifndef COMMONPROPERTIES_H
#define COMMONPROPERTIES_H
#include <QString>
#include <QMap>
#include <QMutex>
typedef struct{
    int nSource;
    QString strSource;
    int nSourceGroup;
    int nReceiveTimestamp;
}HeartbeatData;

enum SourceGroup{
    SP=0,
    DT=1,
    GT=2
};

class CommonProperties
{
public:
    static CommonProperties& getInstance();
    void loadDCSProperties(const QString& filename);
    QString getServerIP(SourceGroup group) const;
    int getServerPort(SourceGroup group) const;

    // Thread-safe access to properties
    QMap<QString, QString> getProperties() const;
    void setProperty(const QString& key, const QString& value);
private:
    CommonProperties(){}
    CommonProperties(const CommonProperties&) = delete;
    CommonProperties& operator=(const CommonProperties&) = delete;

    mutable QMutex mutex;
    QMap<QString, QString> properties;
};

#endif // COMMONPROPERTIES_H
