#include "CommonProperties.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>

CommonProperties& CommonProperties::getInstance()
{
    static CommonProperties instance;
    return instance;
}
void CommonProperties::loadDCSProperties(const QString& filename)
{
    QMutexLocker locker(&mutex);
    QFile file(filename);

    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream stream(&file);
        while (!stream.atEnd()) {
            QString line = stream.readLine();
            if (line.contains("=")) {
                QStringList parts = line.split("=");
                if (parts.size() == 2) {
                    properties[parts[0].trimmed()] = parts[1].trimmed();
                }
            }
        }
        file.close();
    }
}

QString CommonProperties::getServerIP(SourceGroup group) const
{
    QMutexLocker locker(&mutex);
    QString key;
    switch (group) {
        case SP: key = "SP_SERVER_IP"; break;
        case DT: key = "DT_SERVER_IP"; break;
        case GT: key = "GT_SERVER_IP"; break;
    }
    return properties.value(key, "127.0.0.1");
}

int CommonProperties::getServerPort(SourceGroup group) const
{
    QMutexLocker locker(&mutex);
    QString key;
    switch (group) {
        case SP: key = "SP_SERVER_PORT"; break;
        case DT: key = "DT_SERVER_PORT"; break;
        case GT: key = "GT_SERVER_PORT"; break;
    }
    return properties.value(key, "8080").toInt();
}

QMap<QString, QString> CommonProperties::getProperties() const
{
    QMutexLocker locker(&mutex);
    return properties;
}

void CommonProperties::setProperty(const QString& key, const QString& value)
{
    QMutexLocker locker(&mutex);
    properties[key] = value;
}
