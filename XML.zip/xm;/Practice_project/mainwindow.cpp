#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QHostAddress>
#include "splitbin.h"
#include <QVBoxLayout>
#include <QDockWidget>
#include <QPushButton>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
     ,splitBin(new SplitBin(this))
{
    ui->setupUi(this);
    splitBin->hide();
//  // Load properties
    CommonProperties::getInstance().loadDCSProperties("DCS.properties");

    // Create client
    m_client = new Client(this);

    // Create widgets
    heartbeatWidget = new Heartbeat(this);
    statusDisplay = new ConnectionStatusDisplay(this);

    // Setup layout
    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);

    // Control buttons
    QHBoxLayout *buttonLayout = new QHBoxLayout();
    QPushButton *startButton = new QPushButton("Start Clients", this);
    QPushButton *stopButton = new QPushButton("Stop Clients", this);
    buttonLayout->addWidget(startButton);
    buttonLayout->addWidget(stopButton);
    buttonLayout->addStretch();

    mainLayout->addLayout(buttonLayout);
    mainLayout->addWidget(statusDisplay);
    mainLayout->addWidget(heartbeatWidget);

    setCentralWidget(centralWidget);

    // Connect signals
    connect(startButton, &QPushButton::clicked, this, &MainWindow::onStartClicked);
    connect(stopButton, &QPushButton::clicked, this, &MainWindow::onStopClicked);

    connect(m_client, &Client::heartbeatReceived, this, &MainWindow::onHeartbeatReceived);
    connect(m_client, &Client::connectionStatusChanged, this, &MainWindow::onConnectionStatusChanged);

    connect(heartbeatWidget, &Heartbeat::connectionStatusChanged,
            statusDisplay, &ConnectionStatusDisplay::updateConnectionStatus);

    setWindowTitle("TCP/IP Client Application");
    resize(1000, 700);
 }

 MainWindow::~MainWindow() {
     m_client->stopAllClients();
     delete ui;
 }

// void MainWindow::SetupConnections() {
//     connect(m_client, &Client::heartbeatReceived,
//             this, &MainWindow::onHeartbeatReceived);
//     connect(m_client, &Client::connectionStatusChanged,
//             this, &MainWindow::onConnectionStatusChanged);
// }

// void MainWindow::onHeartbeatReceived(const ::HeartbeatData& hb) {
//     m_heartbeatWidget->onHeartbeatReceived(hb);
// }

// void MainWindow::onConnectionStatusChanged(SourceGroup group, bool status) {
//     m_ConnectionStatusWidget->updateConnectionStatus(group, status);
// }



 void MainWindow::onStartClicked()
 {
     m_client->startAllClients();
 }

 void MainWindow::onStopClicked()
 {
     m_client->stopAllClients();
 }

 void MainWindow::onHeartbeatReceived(const HeartbeatData& data)
 {
     heartbeatWidget->addHeartbeatData(data);
 }

 void MainWindow::onConnectionStatusChanged(SourceGroup group, bool connected)
 {
     statusDisplay->updateConnectionStatus(group, connected);
}
