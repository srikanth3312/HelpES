#ifndef HEARTBEAT_H
#define HEARTBEAT_H

#include <QWidget>
#include <QQueue>
#include <QMutex>
#include <QTimer>
#include "CommonProperties.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class Heartbeat;
}
QT_END_NAMESPACE

class Heartbeat : public QWidget
{
    Q_OBJECT

public:
    explicit Heartbeat(QWidget *parent = nullptr);
    ~Heartbeat();
    void addHeartbeatData(const ::HeartbeatData& hb);
    void TriggerToUpdateConnStatus();

signals:
    void connectionStatusChanged(SourceGroup group, bool connected);
public slots:
    void updateTable();
       void checkConnectionTimeout();


private:
    Ui::Heartbeat *ui;
    QQueue<HeartbeatData> heartbeatQueue;
       QMutex queueMutex;
       QTimer *updateTimer;
       QTimer *timeoutTimer;
       QMap<SourceGroup, qint64> lastHeartbeatTime;
};

#endif // HEARTBEAT_H
