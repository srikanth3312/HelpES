#ifndef CLIENT_H
#define CLIENT_H

#include <QObject>
#include <QTcpSocket>
#include <QThread>
#include <QTimer>
#include <QQueue>
#include <QMutex>
#include <QDomDocument>
#include "CommonProperties.h"

class ClientWorker : public QObject{
    Q_OBJECT
public:
    explicit ClientWorker(SourceGroup group,QObject *parent=nullptr);
    ~ClientWorker();
public slots:
    void start();
    void stop();
    void sendHeartbeat();

signals:
    void heartbeatReceived(const HeartbeatData& data);
    void connectionStatusChanged(SourceGroup group, bool connected);
    void error(const QString& errorString);

private slots:
    void onConnected();
    void onDisconnected();
    void onReadyRead();
    void onError(QAbstractSocket::SocketError socketError);
    void connectToServer();

private:
    QTcpSocket *socket;
    SourceGroup sourceGroup;
    QTimer *heartbeatTimer;
    QTimer *reconnectTimer;
    bool isRunning;

    QString createXMLHeartbeat(const HeartbeatData& data);
    QByteArray serializeHeartbeat(const HeartbeatData& data);
    HeartbeatData deserializeHeartbeat(const QByteArray& data);


};

class Client: public QObject{
    Q_OBJECT

public:
    explicit Client(QObject *parent = nullptr);
    ~Client();

    void startAllClients();
    void stopAllClients();

signals:
    void heartbeatReceived(const HeartbeatData& data);
    void connectionStatusChanged(SourceGroup group, bool connected);

private:
    QThread *spThread;
    QThread *dtThread;
    QThread *gtThread;

    ClientWorker *spWorker;
    ClientWorker *dtWorker;
    ClientWorker *gtWorker;

};

#endif // CLIENT_H
