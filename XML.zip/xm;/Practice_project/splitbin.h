#ifndef SPLITBIN_H
#define SPLITBIN_H

#include <QWidget>
#include <QFile>
#include <QDir>
#include <QMessageBox>
#include <QDebug>
#include <QFuture>
#include <QtConcurrent/qtconcurrentrun.h>
#include <QMutex>
#include <QProgressBar>

namespace Ui {
class SplitBin;
}

class SplitBin : public QWidget
{
    Q_OBJECT

public:
    explicit SplitBin(QWidget *parent = nullptr);
    ~SplitBin();
private slots:
    void browseFile1();
    void browseFile2();
    void browseFile3();
    void splitFiles();
    void logMessage(const QString &message);

private:
    Ui::SplitBin *ui;
    QString selectedFile1,selectedFile2,selectedFile3;
    QMutex mutex;
    QString outputBaseDir = "scg";
    static constexpr int PD_SEGMENT_LEN=432;
    static constexpr int PD_EXTRA_ZEROS = 264;
    static constexpr int MP_SEGMENT_LEN = 288;
    const QByteArray DP_START_MARKER = QByteArray::fromHex("333333333333"); // "00110011..."
    const QByteArray DP_END_MARKER = QByteArray::fromHex("7777777777777777"); // "01110111..."

    bool processBinaryFile(const QString &filePath, int fileNumber, QProgressBar *progressBar);
    bool validateFile(const QString &filePath);
};

#endif // SPLITBIN_H
