#include "splitbin.h"
#include "ui_splitbin.h"
#include <QFileDialog>

SplitBin::SplitBin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SplitBin)
{
    ui->setupUi(this);
    connect(ui->browseButton1, &QPushButton::clicked, this, &SplitBin::browseFile1);
       connect(ui->browseButton2, &QPushButton::clicked, this, &SplitBin::browseFile2);
       connect(ui->browseButton3, &QPushButton::clicked, this, &SplitBin::browseFile3);
       connect(ui->splitButton, &QPushButton::clicked, this, &SplitBin::splitFiles);

        // Initialize progress bars
        ui->progressBar1->setValue(0);
        ui->progressBar2->setValue(0);
        ui->progressBar3->setValue(0);
}

SplitBin::~SplitBin()
{
    delete ui;
}

void SplitBin::browseFile1()
{
    selectedFile1 = QFileDialog::getOpenFileName(this, "Select Binary File 1", "", "Binary Files (*.bin)");
    if (!selectedFile1.isEmpty()) {
        ui->filePathLabel1->setText(selectedFile1);
    }
}

void SplitBin::browseFile2()
{
    selectedFile2 = QFileDialog::getOpenFileName(this, "Select Binary File 2", "", "Binary Files (*.bin)");
    if (!selectedFile2.isEmpty()) {
        ui->filePathLabel2->setText(selectedFile2);
    }
}

void SplitBin::browseFile3()
{
    selectedFile3 = QFileDialog::getOpenFileName(this, "Select Binary File 3", "", "Binary Files (*.bin)");
    if (!selectedFile3.isEmpty()) {
        ui->filePathLabel3->setText(selectedFile3);
    }
}

bool SplitBin::validateFile(const QString &filePath)
{
    QFileInfo info(filePath);
    return info.exists() && info.isReadable() && info.size() > 0;
}

void SplitBin::splitFiles()
{
    if (selectedFile1.isEmpty() && selectedFile2.isEmpty() && selectedFile3.isEmpty()) {
        QMessageBox::warning(this, "Error", "No files selected");
        return;
    }

    // Validate files
    if ((!selectedFile1.isEmpty() && !validateFile(selectedFile1))) {
        logMessage("File 1 is invalid or not readable");
        return;
    }
    if ((!selectedFile2.isEmpty() && !validateFile(selectedFile2))) {
        logMessage("File 2 is invalid or not readable");
        return;
    }
    if ((!selectedFile3.isEmpty() && !validateFile(selectedFile3))) {
        logMessage("File 3 is invalid or not readable");
        return;
    }

    // Reset progress bars and UI
    ui->progressBar1->setValue(0);
    ui->progressBar2->setValue(0);
    ui->progressBar3->setValue(0);
    logMessage("Processing files...");
    qApp->processEvents();

    // Process files in parallel
    QList<QFuture<bool>> futures;
    if (!selectedFile1.isEmpty()) {
        futures.append(QtConcurrent::run(this, &SplitBin::processBinaryFile, selectedFile1, 1, ui->progressBar1));
    }
    if (!selectedFile2.isEmpty()) {
        futures.append(QtConcurrent::run(this, &SplitBin::processBinaryFile, selectedFile2, 2, ui->progressBar2));
    }
    if (!selectedFile3.isEmpty()) {
        futures.append(QtConcurrent::run(this, &SplitBin::processBinaryFile, selectedFile3, 3, ui->progressBar3));
    }

    // Wait for all threads to finish
    bool allSuccess = true;
    for (auto &future : futures) {
        future.waitForFinished();
        if (!future.result()) {
            allSuccess = false;
        }
    }

    if (allSuccess) {
        QMessageBox::information(this, "Success", "All files processed successfully");
        logMessage("All files processed successfully");
    } else {
        QMessageBox::warning(this, "Warning", "Some files had processing errors");
        logMessage("Processing completed with some errors");
    }
}

bool SplitBin::processBinaryFile(const QString &filePath, int fileNumber, QProgressBar *progressBar)
{
    // Open input file
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        QMetaObject::invokeMethod(this, "logMessage", Qt::QueuedConnection,
                                Q_ARG(QString, QString("Failed to open file: %1").arg(filePath)));
        return false;
    }

    // Create output directory structure
    QString baseDir = QString("%1/dcs%2").arg(outputBaseDir).arg(fileNumber);
    if (!QDir().mkpath(baseDir + "/pd") ||
        !QDir().mkpath(baseDir + "/mp") ||
        !QDir().mkpath(baseDir + "/dp")) {
        QMetaObject::invokeMethod(this, "logMessage", Qt::QueuedConnection,
                                Q_ARG(QString, QString("Failed to create directories for file %1").arg(fileNumber)));
        return false;
    }

    // Open output files
    QFile pdFile(QString("%1/pd/pd%2.bin").arg(baseDir).arg(fileNumber));
    QFile mpFile(QString("%1/mp/mp%2.bin").arg(baseDir).arg(fileNumber));
    QFile dpFile(QString("%1/dp/dp%2.bin").arg(baseDir).arg(fileNumber));

    if (!pdFile.open(QIODevice::WriteOnly) ||
        !mpFile.open(QIODevice::WriteOnly) ||
        !dpFile.open(QIODevice::WriteOnly)) {
        QMetaObject::invokeMethod(this, "logMessage", Qt::QueuedConnection,
                                Q_ARG(QString, QString("Failed to create output files for file %1").arg(fileNumber)));
        return false;
    }

    // Process file in chunks
    const qint64 chunkSize = 1024 * 1024; // 1MB chunks
    qint64 totalSize = file.size();
    qint64 bytesProcessed = 0;
    QByteArray paddingZeros(PD_EXTRA_ZEROS, '0');

    while (!file.atEnd()) {
        QByteArray chunk = file.read(chunkSize);
        if (chunk.isEmpty()) break;

        int index = 0;
        while (index < chunk.size()) {
            // PD Segment
            if (index + PD_SEGMENT_LEN <= chunk.size()) {
                QByteArray pdData = chunk.mid(index, PD_SEGMENT_LEN);
                pdData.append(paddingZeros);
                if (pdFile.write(pdData) == -1) {
                    QMetaObject::invokeMethod(this, "logMessage", Qt::QueuedConnection,
                                            Q_ARG(QString, QString("Error writing PD data for file %1").arg(fileNumber)));
                    return false;
                }
                index += PD_SEGMENT_LEN;
            } else {
                break;
            }

            // MP Segment
            if (index + MP_SEGMENT_LEN <= chunk.size()) {
                QByteArray mpData = chunk.mid(index, MP_SEGMENT_LEN);
                if (mpFile.write(mpData) == -1) {
                    QMetaObject::invokeMethod(this, "logMessage", Qt::QueuedConnection,
                                            Q_ARG(QString, QString("Error writing MP data for file %1").arg(fileNumber)));
                    return false;
                }
                index += MP_SEGMENT_LEN;
            } else {
                break;
            }

            // DP Segment
            int dpStartPos = chunk.indexOf(DP_START_MARKER, index);
            if (dpStartPos == -1) {
                continue; // No DP marker in this chunk
            }

            int dpEndPos = chunk.indexOf(DP_END_MARKER, dpStartPos);
            if (dpEndPos == -1) {
                // Maybe the end marker is in next chunk
                QByteArray remaining = chunk.mid(dpStartPos);
                QByteArray nextChunk = file.peek(DP_END_MARKER.size() * 2); // Peek ahead
                remaining.append(nextChunk);
                dpEndPos = remaining.indexOf(DP_END_MARKER);
                if (dpEndPos == -1) {
                    QMetaObject::invokeMethod(this, "logMessage", Qt::QueuedConnection,
                                            Q_ARG(QString, QString("No DP end marker found in file %1").arg(fileNumber)));
                    break;
                }
                dpEndPos += dpStartPos; // Adjust position
            }

            int dpLength = dpEndPos - dpStartPos + DP_END_MARKER.size();
            QByteArray dpData = chunk.mid(dpStartPos, dpLength);
            if (dpFile.write(dpData) == -1) {
                QMetaObject::invokeMethod(this, "logMessage", Qt::QueuedConnection,
                                        Q_ARG(QString, QString("Error writing DP data for file %1").arg(fileNumber)));
                return false;
            }
            index = dpEndPos + DP_END_MARKER.size();
        }

        bytesProcessed += chunk.size();
        int progress = static_cast<int>((static_cast<double>(bytesProcessed) / totalSize) * 100);
        QMetaObject::invokeMethod(progressBar, "setValue", Qt::QueuedConnection, Q_ARG(int, progress));
    }

    // Close files (RAII would handle this, but explicit for clarity)
    pdFile.close();
    mpFile.close();
    dpFile.close();

    QMetaObject::invokeMethod(this, "logMessage", Qt::QueuedConnection,
                            Q_ARG(QString, QString("File %1 processing completed").arg(fileNumber)));
    return true;
}

void SplitBin::logMessage(const QString &message)
{
    QMutexLocker locker(&mutex);
    QString current = ui->statusLabel->text();
    if (!current.isEmpty()) {
        current += "\n";
    }
    ui->statusLabel->setText(current + message);
    qDebug() << message;
    qApp->processEvents();
}
