#include "structure.h"
#include <QFile>
#include <QDataStream>

QByteArray createPddStructure(int dcs_id, const QString& pdFilePath) {
    pdd packet;

    // Initialize header
    memcpy(packet.header, HEADER, 8);

    // Set DCS ID
    switch(dcs_id) {
        case 1: packet.dcs_id = DCS_ID_1; break;
        case 2: packet.dcs_id = DCS_ID_2; break;
        case 3: packet.dcs_id = DCS_ID_3; break;
        default: packet.dcs_id = 0;
    }

    // Initialize all numeric fields to 0
    packet.bin_id = 0;
    packet.freq_min = 0;
    packet.freq_max = 0;
    packet.pulse_width_min = 0;
    packet.pulse_width_max = 0;
    packet.start_time = 0;
    packet.end_time = 0;
    packet.pdData_repeation_count = 0;

    // Set EOF marker
    for(int i = 0; i < 6; i++) {
        packet.EndofFrame[i] = EOF_MARKER;
    }

    // Create byte array from structure
    QByteArray structureData(reinterpret_cast<char*>(&packet), sizeof(pdd));

    // Append the actual PD data from file
    QFile pdFile(pdFilePath);
    if(pdFile.open(QIODevice::ReadOnly)) {
        structureData.append(pdFile.readAll());
        pdFile.close();
    }

    return structureData;
}
