#include "ConnectionStatusDisplay.h"
#include "ui_ConnectionStatusDisplay.h"
#include <QPalette>

ConnectionStatusDisplay::ConnectionStatusDisplay(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ConnectionStatusDisplay)
{
    ui->setupUi(this);
   // setupStatusLabels();
}

ConnectionStatusDisplay::~ConnectionStatusDisplay()
{
    delete ui;
}
void ConnectionStatusDisplay::updateConnectionStatus(SourceGroup group, bool connected)
{
    setServerStatus(group, connected);
}

void ConnectionStatusDisplay::setServerStatus(SourceGroup group, bool connected)
{
    QString color = connected ? "green" : "red";
    QString style = QString("background-color: %1; border: 2px solid black; border-radius: 10px;").arg(color);

    switch (group) {
        case SP:
            ui->labelSPStatus->setStyleSheet(style);
            break;
        case DT:
            ui->labelDTStatus->setStyleSheet(style);
            break;
        case GT:
            ui->labelGTStatus->setStyleSheet(style);
            break;
    }
}
